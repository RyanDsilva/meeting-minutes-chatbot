"use strict";

const functions = require("firebase-functions");
const { google } = require("googleapis");
const { WebhookClient } = require("dialogflow-fulfillment");

const calendarId = "b9d980catrt42vjkcl73qio7a0@group.calendar.google.com";
const serviceAccount = {
  type: "service_account",
  project_id: "meeting-minutes-lxlbms",
  private_key_id: "50480fcef7606af5b616880c234225f5f01dc1b3",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCqCtUvss47S8+V\nDmwTsQM6lALGx+nG9SEdMraqADUjBaMGQpLwMfNWcWgqngaeFGzxjaB12p5wDBcJ\no3yMjXwZpx5CzpdoakJsPG0atrWslbGHXJxngUP/PsrFipTpN8Jf9cDcL4IleNED\nx4PgmX5sfbBB5k738cAQr7591JtlPwt+vz833T5xQ8leqVyIId2166QtnOZJ5j5u\nG1ltyA6QnKPxgwhLyq5P+JBA/0ZIigMRNsA3wrTFrqrbnq1t4Wz3IycaEBB91Czz\nyccnm5WV6buWJFUJbvra+IvWbi+vqsq11OEeF2FkF7O+jFsmRjbpMq8DKLprXoLM\nKUUVoSRVAgMBAAECggEACxOLkYDXODuW+QGofpvgNvefOq2ZB9G953X/OhGrZG2g\nke7SPX0zeaUHgQcsLS3tbsqn8iVcfrX65jDVEx7AP7eIHBfy+uU5EG3bOYs/SE+z\n8bpRodhkwoKnmLiPPKXaLoAGoREjLCezjch4SbAV8SE60wAaksIXnb6k7PNlb/HR\nH7qBRXqyPh1PXw1nbqj8Xcv1LkJWbMRUu0NH1fC2GFwYZAO4Y+Taic38fKzSiO/w\n4yOW4ePelHuVeaXbNo4M86G9nC7HnE5uxm4E2S4I8HP6cnaAUUbTLcdEUkX7vj34\nw6DB4nQOzq4GITbSfOMAypSYt3x94B5TV8LtR6DK4QKBgQDgfVwO5PYy7eXCARnU\numqTQ5/RUHaSuwR4qsK7y2DQ4+3CFyGGjiZV8xHnYS860L1XYjNjd3Q6Vl7jGBdG\nZ2uNoVAduYPJA8Q+pgVPtPZNXqLA+M7UQqRzcfzo1Lmo2F0jV1uY0kLBMBE3nW3B\nRpEibm9a+XG8GcjaaKicG37yyQKBgQDB6QDIV3ZDaffQxgl5hwyuuYSN1B+hB4zy\n8VccVPPr/rT0MklBeqTb5Dctmhy68kixfuQO4pAN34AdzYYIEo7ZLXwhME+a03iC\nQEmEY4p4OGvsvFcTSiu1XmbpfuX/qVNZrPCGxPfAPc9i7cpdccINXlC2jyEdGvFC\njyR87Yk/LQKBgHp8K7R8vNBA+TGHRD7Lj8bWCOc+DdQ1clUcZq/sYeDX3CwgTsyJ\n1uTigQxL/GcM6aI6FGvbC3GhGpix1lE1sHtQXtQ5GmydP4AnOZKp3BGO5yJ/Huq1\nieDreuDW4I39r6PO0E1ru7yIq3w6y12/UQUGWH+8xo+pSevRWt4CKpvxAoGACoDy\nl+eU8mXlFJwFm12jZDuMYJpi9DgSfH5yN4iqhdgQOUIYEcHw+DBOhNvaPo4tPeAf\nvmarYvT+XZ7qabmHn2AFX07coQhfeL6+vLsfnw9/WR2Cofrcj0CD1pYXI1gquarS\nhJpayUEP4M38rj8hQdQgDyOFqavx8acLVPERBCkCgYAcUPty8y123LD/qC+k2pWH\npKGwrJYSpcXv7xAXfItCOY5SujzAHTsdgGDcJKja+aQllMQoekG0kWrUnTWuhlcr\nijtOp/ycAfibAVrTsCX3t5gSNp6ZP9tn6ydLfCw42Xmvbs+QTBIZEV9jO9J2mN/S\nni1/L1LlelwUnBUlWh7scw==\n-----END PRIVATE KEY-----\n",
  client_email: "meeting-minutes-lxlbms@appspot.gserviceaccount.com",
  client_id: "116602304607518311976",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/meeting-minutes-lxlbms%40appspot.gserviceaccount.com"
};

const serviceAccountAuth = new google.auth.JWT({
  email: serviceAccount.client_email,
  key: serviceAccount.private_key,
  scopes: "https://www.googleapis.com/auth/calendar"
});

const calendar = google.calendar("v3");
process.env.DEBUG = "dialogflow:debug";

const timeZone = "Asia/Kolkata";
const timeZoneOffset = "+05:30";

exports.dialogflowFirebaseFulfillment = functions.https.onRequest(
  (request, response) => {
    const agent = new WebhookClient({ request, response });
    console.log("parameters", agent.parameters);
    const appointment_type = agent.parameters.AppointmentType;
    function makeAppointment(agent) {
      const dateTimeStart = new Date(
        agent.parameters.date.split("T")[0] +
          " " +
          agent.parameters.time.split("T")[1].split("+")[0] +
          " " +
          timeZoneOffset
      );
      const dateTimeEnd = new Date(
        new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1)
      );
      const appointmentTimeString = dateTimeStart.toLocaleString("en-US", {
        month: "long",
        day: "numeric",
        hour: "numeric",
        timeZone: timeZone
      });
      return createCalendarEvent(dateTimeStart, dateTimeEnd, appointment_type)
        .then(() => {
          agent.add(
            `Ok, let me see if we can fit you in. ${appointmentTimeString} is fine!.`
          );
        })
        .catch(() => {
          agent.add(
            `I'm sorry, there are no slots available for ${appointmentTimeString}.`
          );
        });
    }
    let intentMap = new Map();
    intentMap.set("schedule", makeAppointment);
    agent.handleRequest(intentMap);
  }
);

function createCalendarEvent(dateTimeStart, dateTimeEnd, appointment_type) {
  return new Promise((resolve, reject) => {
    calendar.events.list(
      {
        auth: serviceAccountAuth,
        calendarId: calendarId,
        timeMin: dateTimeStart.toISOString(),
        timeMax: dateTimeEnd.toISOString()
      },
      (err, calendarResponse) => {
        if (err || calendarResponse.data.items.length > 0) {
          reject(
            err ||
              new Error("Requested time conflicts with another appointment")
          );
        } else {
          calendar.events.insert(
            {
              auth: serviceAccountAuth,
              calendarId: calendarId,
              resource: {
                summary: appointment_type + " Meeting",
                description: appointment_type,
                start: { dateTime: dateTimeStart },
                end: { dateTime: dateTimeEnd }
              }
            },
            (err, event) => {
              err ? reject(err) : resolve(event);
            }
          );
        }
      }
    );
  });
}
